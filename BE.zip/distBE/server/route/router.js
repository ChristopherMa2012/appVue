'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _model = require('../model/model');

var _model2 = _interopRequireDefault(_model);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let router = _express2.default.Router();

router.use('/register', (req, res, next) => {
    let user = new _model2.default.User({
        name: req.body.userName,
        password: req.body.password,
        point: 0,
        redPaper: 2,
        discount: 0
    });
    user.save(err => {
        if (err) return handleError(err);
        res.send({ "success": true, 'msg': '注册成功' });
    });
});
// status: 200 登陆成功
// status: 202 用户已登录
// status: 300 当前已有用户登陆，是否切换用户
// status: 400 登陆失败
// status: 402 用户未登录

//登录
router.use('/login', (req, res) => {
    if (req.body.name == '' || req.body.password == '') {
        res.send({ status: 400, msg: '登陆失败' });
        return;
    }
    let session = req.session;
    if (session.isLogin) {
        if (req.body.name == session.userInfo.name) {
            res.send({ status: 202, msg: '用户已登录' });
        } else {
            res.send({ status: 300, msg: '当前已有用户登陆' });
        }
    } else {
        _model2.default.User.findOne({ 'name': req.body.name, 'password': req.body.password }, (err, result) => {
            if (err) {
                res.send({ status: 400, msg: '登陆失败' });
                handleError(err);
            }
            if (result) {
                session.isLogin = true;
                session.userInfo = Object.create(null);
                session.userInfo.name = result.name;
                session.userInfo.userId = result.id;
                session.userInfo.point = result.point;
                session.userInfo.redPaper = result.redPaper;
                session.userInfo.discount = result.discount;
                res.send({ status: 200, msg: '登陆成功' });
            } else {
                res.send({ status: 400, msg: '登陆失败' });
            }
        });
    }
});
//校验是否已经登录
router.use('/isLogin', (req, res) => {
    if (req.session.isLogin) {
        res.send({ status: 202, msg: '用户已登录' });
    } else {
        res.send({ status: 402, msg: '用户未登录' });
    }
});
//商品上架
router.use('/addGood', (req, res) => {
    let obj = req.body;
    //Object.setPrototypeof(obj,null);
    //let obj = Object.create(null);
    // obj.gdSN = 234234324;
    // Object.keys(body).forEach(item => {
    //     obj[item] = body[item];
    // })
    let goods = new _model2.default.Goods(obj);
    goods.save(err => {
        if (err) return handleError(err);
        res.send({ status: 200, 'msg': '添加成功' });
    });
});
//商品列表
router.get('/goodsList', (req, resp) => {
    let type = req.query.goods_type;
    if (type) {
        _model2.default.Goods.find({ goods_type: type }, (err, result) => {
            if (err) return handleError(err);
            resp.send({ status: 200, goodsList: result });
        });
    } else {
        let goodsList = [];
        _model2.default.Goods.find({ goods_type: 1 }, (err, res) => {
            if (err) return handleError(err);
            goodsList.push(res);
            _model2.default.Goods.find({ goods_type: 2 }, (err, res) => {
                if (err) return handleError(err);
                goodsList.push(res);
                _model2.default.Goods.find({ goods_type: 3 }, (err, res) => {
                    if (err) return handleError(err);
                    goodsList.push(res);
                    _model2.default.Goods.find({ goods_type: 4 }, (err, res) => {
                        if (err) return handleError(err);
                        goodsList.push(res);
                        resp.send({ status: 200, goodsList: goodsList });
                    });
                });
            });
        });
    }
});
//商品详情
router.get('/gdDetail', (req, res) => {
    let gdSN = req.query.gdSN;
    _model2.default.Goods.find({ gdSN: gdSN }, (err, result) => {
        if (err) return handleError(err);
        res.send({ status: 200, goodsInfo: result[0] });
    });
});
exports.default = router;
//# sourceMappingURL=router.js.map