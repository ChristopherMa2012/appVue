'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _router = require('./router');

var _router2 = _interopRequireDefault(_router);

var _verifyRouter = require('./verifyRouter');

var _verifyRouter2 = _interopRequireDefault(_verifyRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = app => {
    app.use(_router2.default);
    app.use(_verifyRouter2.default);
};
//# sourceMappingURL=index.js.map