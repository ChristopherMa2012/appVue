'use strict';

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _bodyParser = require('body-parser');

var _bodyParser2 = _interopRequireDefault(_bodyParser);

var _cookieParser = require('cookie-parser');

var _cookieParser2 = _interopRequireDefault(_cookieParser);

var _expressSession = require('express-session');

var _expressSession2 = _interopRequireDefault(_expressSession);

var _index = require('./server/route/index');

var _index2 = _interopRequireDefault(_index);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import { fail } from 'assert';

let app = (0, _express2.default)();
//import path from 'path';

console.log('server启动中。。。。。');
// app.get('/',function(req,res){
// 	res.sendFile(path.join(__dirname,'\static\\index.html'));
// });
// express.static('/src');
app.use(_bodyParser2.default.json());
app.use(_bodyParser2.default.urlencoded({ extended: false }));
app.use((0, _cookieParser2.default)());
_mongoose2.default.connect('mongodb://localhost/appvue');

app.all("*", (req, res, next) => {
	res.set("Access-Control-Allow-origin", "http://vueapp.tech");
	res.set("Access-Control-Allow-Headers", "Content-Type");
	//res.set("Access-Control-Allow-Methods", "GET,PUT,POST");
	res.set("Access-Control-Allow-Credentials", true);
	if (req.method === 'OPTIONS') {
		res.status(200).end();
		return;
	}
	next();
});
app.use((0, _expressSession2.default)({
	secret: 'CHRISMA',
	cookie: {
		domain: '.vueapp.tech',
		maxAge: 7200 * 1000,
		secure: false,
		httpOnly: true
	}
}));
(0, _index2.default)(app);

app.listen(process.env.PORT || 800);
console.log('server正监听800端口，请访问  http://vueapp.tech:800');
//# sourceMappingURL=app.js.map